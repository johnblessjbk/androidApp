package codewithcal.au.ciperit.ADAPTOR;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import codewithcal.au.ciperit.BEAN.UserBean;
import codewithcal.au.ciperit.R;

public class FeedBackList extends ArrayAdapter<UserBean> {

    String name,status,email,phone,dtae;

    TextView NAME,STATUS,EMAIL,PHONE,DTAE;

    List<UserBean> prodList;
    Activity context;

    public FeedBackList(Activity context, List<UserBean> prodList) {
        super(context, R.layout.activity_feed_back_list, prodList);
        this.prodList = prodList;
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View view = inflater.inflate(R.layout.activity_feed_back_list, null, true);
        NAME = view.findViewById(R.id.username);
        EMAIL = view.findViewById(R.id.useremail);
        PHONE = view.findViewById(R.id.userphone);
        DTAE = view.findViewById(R.id.userdate);
        STATUS = view.findViewById(R.id.sattusid);
        name = prodList.get(position).getName();
        email = prodList.get(position).getEmail();
        phone=prodList.get(position).getPhone();
        dtae = prodList.get(position).getUserdate();
        status=prodList.get(position).getStatus();

        NAME.setText(name);
        EMAIL.setText(email);
        PHONE.setText(phone);
        DTAE.setText(dtae);
STATUS.setText("Rate :"+status);
        return view;

    }
}
