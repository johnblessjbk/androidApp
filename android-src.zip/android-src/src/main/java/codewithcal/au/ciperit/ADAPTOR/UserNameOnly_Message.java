package codewithcal.au.ciperit.ADAPTOR;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import codewithcal.au.ciperit.BEAN.UserBean;
import codewithcal.au.ciperit.R;

public class UserNameOnly_Message extends ArrayAdapter<UserBean> {

    String name,status,email,phone,dtae;

    TextView NAME,STATUS,EMAIL,PHONE,DTAE;

    List<UserBean> prodList;
    Activity context;

    public UserNameOnly_Message(Activity context, List<UserBean> prodList) {
        super(context, R.layout.activity_user_name_only_message, prodList);
        this.prodList = prodList;
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View view = inflater.inflate(R.layout.activity_user_name_only_message, null, true);
        NAME = view.findViewById(R.id.username);
        name=prodList.get(position).getName();
        NAME.setText(name);

        return view;

    }
}
