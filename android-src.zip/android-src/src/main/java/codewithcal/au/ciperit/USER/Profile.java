package codewithcal.au.ciperit.USER;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import codewithcal.au.ciperit.ADAPTOR.FeedBackList;
import codewithcal.au.ciperit.BEAN.UserBean;
import codewithcal.au.ciperit.COMMON.Utility;
import codewithcal.au.ciperit.R;

public class Profile extends Fragment {
EditText name,emai,phone,dates,pass;
String NAME,EMAIL,PHONE,DATE,PASS;
Button updatebtn;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View viewl= inflater.inflate(R.layout.fragment_profile, container, false);
        name=viewl.findViewById(R.id.pname);
        emai=viewl.findViewById(R.id.pemail);
        phone=viewl.findViewById(R.id.phonee);
        dates=viewl.findViewById(R.id.pdate);
        pass=viewl.findViewById(R.id.pass);
        updatebtn=viewl.findViewById(R.id.updatebtn);
        getprofile();
updatebtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        NAME=name.getText().toString();
        EMAIL=emai.getText().toString();
        PHONE=phone.getText().toString();
        DATE=dates.getText().toString();
        PASS=pass.getText().toString();

        com.android.volley.RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.POST, Utility.url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("response : ", response);
                if (!response.trim().equals("failed")) {

                    Toast.makeText(getContext(), "Updated", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "error", Toast.LENGTH_SHORT).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "my Error :" + error, Toast.LENGTH_LONG).show();
                Log.i("My Error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<String, String>();

                SharedPreferences shobjmail = getActivity().getSharedPreferences("profilepefer", MODE_PRIVATE);
                String uid=shobjmail.getString("u_id","");
                map.put("key", "updateprofile");
                map.put("uid",uid);
                map.put("NAME",NAME);
                map.put("email",EMAIL);
                map.put("phone",PHONE);
                map.put("dates",DATE);
                map.put("pass",PASS);

                return map;
            }
        };
        queue.add(request);

    }
});
        return  viewl;
    }

    public void getprofile() {
        com.android.volley.RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.POST, Utility.url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("response : ", response);
                if (!response.trim().equals("failed")) {

                    String data = response;
                    String respArr[] = data.trim().split("#");
                    name.setText(respArr[0]);
                    emai.setText(respArr[1]);
                    phone.setText(respArr[2]);
                    dates.setText(respArr[3]);
                    pass.setText(""+respArr[4]);

                } else {

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "my Error :" + error, Toast.LENGTH_LONG).show();
                Log.i("My Error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<String, String>();

                SharedPreferences shobjmail = getActivity().getSharedPreferences("profilepefer", MODE_PRIVATE);
                String uid=shobjmail.getString("u_id","");
                map.put("key", "getaprofuile");
                map.put("uid",uid);
                return map;
            }
        };
        queue.add(request);
    }



}