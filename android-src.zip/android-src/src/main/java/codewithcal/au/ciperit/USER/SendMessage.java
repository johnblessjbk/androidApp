package codewithcal.au.ciperit.USER;

import static android.content.Context.MODE_PRIVATE;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import codewithcal.au.ciperit.ADAPTOR.UserList;
import codewithcal.au.ciperit.ADAPTOR.UserNameOnly_Message;
import codewithcal.au.ciperit.BEAN.UserBean;
import codewithcal.au.ciperit.COMMON.Utility;
import codewithcal.au.ciperit.R;
import codewithcal.au.ciperit.databinding.FragmentGalleryBinding;


public class SendMessage extends Fragment {

    String uid, username;
    List<UserBean> blist;
    private FragmentGalleryBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentGalleryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        geAllUserNames();
        return root;
    }

    public void geAllUserNames() {
        com.android.volley.RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.POST, Utility.url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("response : ", response);
                if (!response.trim().equals("failed")) {
                    Gson gson = new Gson();
                    blist = Arrays.asList(gson.fromJson(response, UserBean[].class));
                    Log.d("Data", "" + blist.get(0).getEmail());
                    UserNameOnly_Message adapter = new UserNameOnly_Message(getActivity(), blist);
                    binding.userlidtlviewid.setAdapter(adapter);
                    registerForContextMenu(binding.userlidtlviewid);
                    binding.userlidtlviewid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            uid = blist.get(position).getUid();
                            AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
                            dialog.setCancelable(false);
                            username = blist.get(position).getName();
                            String phone = blist.get(position).getPhone();
                            String uid = blist.get(position).getUid();

                            dialog.setTitle("Message");
                            dialog.setMessage("Sending Message To -" + username);
                            dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int id) {
                                    SharedPreferences.Editor editor =getContext(). getSharedPreferences("sendmessage", Context.MODE_PRIVATE).edit();
                                    editor.putString("user_id", "" + uid);
                                    editor.putString("user_phone", "" + phone);

                                    editor.commit();
                                    MessagePage fragment = new MessagePage();
                                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                                    transaction.replace(R.id.nav_host_fragment_content_user_home, fragment);
                                    transaction.commit();
                                }
                            }).setNegativeButton("No ", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //startActivity(new Intent(getApplicationContext(), Register.class));
                                    dialog.dismiss();
                                }
                            });
                            AlertDialog alert = dialog.create();
                            alert.show();
                        }
                    });//                    }
                } else {

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "my Error :" + error, Toast.LENGTH_LONG).show();
                Log.i("My Error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<String, String>();
                SharedPreferences shobjmail = getActivity().getSharedPreferences("profilepefer", MODE_PRIVATE);
                String uid=shobjmail.getString("u_id","");
                map.put("key", "getalluserdataonly");
                map.put("uid",uid);
                return map;
            }
        };
        queue.add(request);
    }

}