package codewithcal.au.ciperit.ADMIN.ui.main;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import codewithcal.au.ciperit.ADAPTOR.UserList;
import codewithcal.au.ciperit.BEAN.UserBean;
import codewithcal.au.ciperit.COMMON.Utility;
import codewithcal.au.ciperit.R;
import codewithcal.au.ciperit.databinding.FragmentAdminHomeBinding;


public class PlaceholderFragment extends Fragment {

    private FragmentAdminHomeBinding binding;

String uid,username;
    List<UserBean> blist;
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        binding = FragmentAdminHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        UserLIST_ToAction();
        return root;
    }

    public void UserLIST_ToAction() {
        com.android.volley.RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.POST, Utility.url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("response : ", response);
                if (!response.trim().equals("failed")) {
                    Gson gson = new Gson();
                    blist = Arrays.asList(gson.fromJson(response, UserBean[].class));
                    Log.d("Data", "" + blist.get(0).getEmail());
                    UserList adapter = new UserList(getActivity(), blist);
                    binding.userlidtlviewid.setAdapter(adapter);
                    registerForContextMenu(binding.userlidtlviewid);
                    binding.userlidtlviewid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            uid=blist.get(position).getUid();
                            AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
                            dialog.setCancelable(false);
                            username=blist.get(position).getName();

                            dialog.setTitle("PERMISSION");
                            dialog.setMessage("Access Permission :To "+username);
                            dialog.setPositiveButton("Approve", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int id) {
                                    //  startActivity(new Intent(getActivity(), Shopregistration.class));
                                    Approveuser();

                                }
                            })  .setNegativeButton("Reject ", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //startActivity(new Intent(getApplicationContext(), Register.class));
                                    blockuserreporter();
                                }
                            });
                            AlertDialog alert = dialog.create();
                            alert.show();
                        }
                    });//                    }
                } else {

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "my Error :" + error, Toast.LENGTH_LONG).show();
                Log.i("My Error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<String, String>();
                map.put("key", "getuserToApprove");
                return map;
            }
        };
        queue.add(request);
    }

    //remove userlist
    public void blockuserreporter(){
        com.android.volley.RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.POST, Utility.url, new Response.Listener<String>() {
            @Override

            public void onResponse(String response) {
                Log.d("******", response);

                if (!response.trim().equals("failed")) {
                    Log.d("******", response);
                    Toast.makeText(getContext(), "Rejected" + response, Toast.LENGTH_SHORT).show();
//                    PlaceholderFragment fragment = new PlaceholderFragment();
//                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
//                    transaction.replace(androidx.navigation.fragment.R.id., fragment);
//                    transaction.commit();

                } else {
                    Toast.makeText(getContext(), "" + response, Toast.LENGTH_LONG).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getContext(), "my Error :" + error, Toast.LENGTH_LONG).show();
                Log.i("My Error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<String, String>();
                map.put("key", "rejectdata");
                map.put("userid", uid);

                return map;
            }
        };
        queue.add(request);
    }

    //remove userlist
    public void Approveuser(){
        com.android.volley.RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.POST, Utility.url, new Response.Listener<String>() {
            @Override

            public void onResponse(String response) {
                Log.d("******", response);

                if (!response.trim().equals("failed")) {
                    Log.d("******", response);
                    Toast.makeText(getContext(), "Approve" + response, Toast.LENGTH_SHORT).show();
//                    PlaceholderFragment fragment = new PlaceholderFragment();
//                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
//                    transaction.replace(androidx.navigation.fragment.R.id.nav_host_fragment_container, fragment);
//                    transaction.commit();

                } else {
                    Toast.makeText(getContext(), "" + response, Toast.LENGTH_LONG).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getContext(), "my Error :" + error, Toast.LENGTH_LONG).show();
                Log.i("My Error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<String, String>();
                map.put("key", "approvedata");
                map.put("userid", uid);

                return map;
            }
        };
        queue.add(request);
    }
}
