package codewithcal.au.ciperit.USER;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

import codewithcal.au.ciperit.COMMON.Utility;
import codewithcal.au.ciperit.R;
import codewithcal.au.ciperit.databinding.FragmentHomeBinding;


public class FeedBack extends Fragment {

    Spinner down;
    String feedto,fn,fd,rba,ba,da;
    EditText fname,fdes;
    Button fbtn;
    RatingBar rb;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        fname = root.findViewById(R.id.fname);
        fdes = root.findViewById(R.id.feeddes);
        fbtn = root.findViewById(R.id.feedbtn);
        rb = root.findViewById(R.id.starid);

        fbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getContext(), ""+down, Toast.LENGTH_SHORT).show();
                String nnn=String.valueOf(down);

                fn = fname.getText().toString();
                fd = fdes.getText().toString();
                float rbar = rb.getRating();
                ba=String.valueOf(rbar);
                if (fn.isEmpty()) {
                    fname.requestFocus();
                    fname.setError("Enter Feeder Name");
                } else if (fd.isEmpty()) {
                    fdes.requestFocus();
                    fdes.setError("Enter Description");
                } else {
                    sendfed();

                }   }
        });

        return root;
    }
    public void sendfed(){
        com.android.volley.RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.POST, Utility.url, new Response.Listener<String>() {
            @Override

            public void onResponse(String response) {
                Log.d("******", response);

                if (!response.trim().equals("failed")) {
                    Log.d("******", response);
                    Toast.makeText(getContext(), "" + response, Toast.LENGTH_SHORT).show();
                    FeedBack fragment = new FeedBack();
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                    transaction.replace(R.id.nav_host_fragment_content_user_home, fragment);
                    transaction.commit();
                } else {
                    Toast.makeText(getContext(), "" + response, Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getContext(), "my Error :" + error, Toast.LENGTH_LONG).show();
                Log.i("My Error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<String, String>();
                map.put("key", "Feedback");
                SharedPreferences obj = getActivity().getSharedPreferences("profilepefer", MODE_PRIVATE);
                String uid = obj.getString("u_id", "");
                map.put("title", fn.trim());
                map.put("description", fd.trim());
                map.put("star", ba.toString().trim());
                map.put("uid", uid.toString().trim());

                return map;
            }
        };
        queue.add(request);
    }
}
