package codewithcal.au.ciperit.COMMON;

public class Utility {
    public static  String ip="192.168.0.79";
    public static String url="http://"+ip+":8080/Ciper_It_Server/Server_Controller.jsp";
  }
