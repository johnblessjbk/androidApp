package codewithcal.au.ciperit.USER;

import static android.content.Context.MODE_PRIVATE;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import codewithcal.au.ciperit.CODE_ALGORITHM.AES;
import codewithcal.au.ciperit.COMMON.Base64;
import codewithcal.au.ciperit.COMMON.Utility;
import codewithcal.au.ciperit.R;
import codewithcal.au.ciperit.databinding.FragmentSlideshowBinding;


public class SearchKey extends Fragment {
    String Content, IMAGE, MESSAGE, DECRPTEDMSH;
    private FragmentSlideshowBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentSlideshowBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        binding.searchenter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Content = binding.SEarchkeycontent.getText().toString();
                getimages();
                binding.mydataimgdisplay.setVisibility(View.VISIBLE);

                binding.PAgeofkey.setBackgroundColor(getResources().getColor(android.R.color.white));

            }
        });


        return root;
    }

    void getimages() {

        com.android.volley.RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.POST, Utility.url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("response : ", response);
                if (!response.trim().equals("failed")) {

                    String data = response;
                    String respArr[] = data.trim().split("#");
                    IMAGE = respArr[1].toString();
                    MESSAGE = respArr[0].toString();
                    DECRPTEDMSH = respArr[2].toString();

                    byte[] imageAsBytes = new byte[0];
                    try {
                        imageAsBytes = Base64.decode(IMAGE.getBytes());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    binding.mydataimgdisplay.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.length));
                    binding.resut.setVisibility(View.GONE);

                    binding.mydataimgdisplay.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
                            dialog.setCancelable(false);

                            dialog.setTitle("Message ");
                            dialog.setMessage("Select Your Message Option");
                            dialog.setPositiveButton("encrypted", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int id) {
                                    Show_Selected_Message("encrypted");

                                }
                            }).setNegativeButton("Decrypted ", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    Show_Selected_Message("Decrypted");
                                }
                            });
                            AlertDialog alert = dialog.create();
                            alert.show();
                        }
                    });
                } else {
                    Toast.makeText(getContext(), "In This Key Have No Message", Toast.LENGTH_SHORT).show();
                    binding.getrest.setText("In This Key Have No Message");
                    binding.resut.setVisibility(View.VISIBLE);
                    binding.mydataimgdisplay.setVisibility(View.INVISIBLE);

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "my Error :" + error, Toast.LENGTH_LONG).show();
                Log.i("My Error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<String, String>();

                SharedPreferences shobjmail = getActivity().getSharedPreferences("profilepefer", MODE_PRIVATE);
                String uid = shobjmail.getString("u_id", "");
                map.put("key", "getimagedata");
                map.put("uid", uid);
                map.put("Searchkeyvalue", Content);
                return map;
            }
        };
        queue.add(request);
    }

    public void Show_Selected_Message(String option) {
        if (option.equals("encrypted")) {
            binding.resut.setVisibility(View.VISIBLE);
            binding.getrest.setText(MESSAGE);
            binding.PAgeofkey.setBackgroundColor(getResources().getColor(R.color.lignt));

            binding.mydataimgdisplay.setVisibility(View.INVISIBLE);
        } else if (option.equals("Decrypted")) {
            System.out.println("DECRYPTED DATA ....is entry");
            binding.resut.setVisibility(View.VISIBLE);
            binding.getrest.setText(DECRPTEDMSH);
            binding.mydataimgdisplay.setVisibility(View.INVISIBLE);
            binding.PAgeofkey.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));

        } else {
            binding.resut.setVisibility(View.VISIBLE);

            binding.getrest.setText("Some Thing Went Wrong");

        }


    }
}

